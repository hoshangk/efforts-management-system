<?php 
  error_reporting(E_ERROR | E_WARNING | E_PARSE);
  session_start();
  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Project</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style>
    .designer {
      display: none;
    }
    .developer {
      display: none;
    }
    .operation {
      display: none;
    }
  </style>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script type="text/javascript">
    $(document).ready(function(){
      $('input[type=radio][name=role]').change(function(){
        selected_value = $("input[name='role']:checked").val();
          console.log(selected_value);
          if(selected_value == 'developer')
          {
             $(".developer").show();
             $(".designer").hide();
             $(".operation").hide();
             var developerVal = $("#dev option:selected").val();
             console.log(developerVal);
          }           
          else if(selected_value == "designer")
          {
              $(".designer").show();
              $(".developer").hide();
              $(".operation").hide();
          }
          else
          {
              $(".designer").hide();
              $(".operation").show();
              $(".developer").hide();
          }          
      });

      $('select[name=role]').change(function(){
            console.log("Developer Selected");
      });         
    })
  </script>
</head>

<body>
  <div class="header">
    <h2>Add Project Page</h2>
  </div>
  <div class="content1">
    <form method="post" action="add_project_process.php">
    <?php include('errors.php'); ?>
    <div class="input-group">
      <label>Title</label>
      <input type="text" name="title" value="<?php #echo $title; ?>">
    </div>
    <div class="input-group">
      <label>Description</label>
      <textarea name="description" value="<?php echo $description; ?>" rows="6" cols="45"></textarea>
    </div>
    <div class="task">
      <label for="resouces"r>Resources</label><br>
      <input type="radio" name="role" value="developer">
      <label for="developer">Developer</label>
      <div class="developer">
            <select class="browser-default custom-select dropdown-primary" name="developer" id="dev">
              <option value="">Select Developer</option>
              <option value="dharmendra">Dharmendra</option>
              <option value="harshita">Harshita</option>
              <option value="mustafa">Mustafa</option>
            </select>
      </div>
      <br>
      <input type="radio" id="designer" name="role" value="designer">
      <label for="designer">Designer</label>
      <div class="designer">
          <select class="browser-default custom-select dropdown-primary" name="designer">
              <option value="">Select Designer</option>
              <option value="bhagyashree">Bhagyashree</option>
          </select>
      </div>
      <br>
      <input type="radio" id="operation" name="role" value="operation">
      <label for="operation">Operation</label>
      <div class="operation">
          <select class="browser-default custom-select dropdown-primary"  name="operation">
              <option value="">Select Resource</option>
              <option value="hitendra">Hitendra</option>
          </select>
      </div>
      <input type="hidden" name="resource" value="">
    </div>
    <div class="input-group">
      <button type="submit" class="btn" name="assign_prj">Assign Project</button>
    </div>

  </div>

</body>
</html>