-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2020 at 01:11 PM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ems`
--

-- --------------------------------------------------------

--
-- Table structure for table `graphics_requeest_tl_updates`
--

CREATE TABLE `graphics_requeest_tl_updates` (
  `request_id` int(4) NOT NULL,
  `tl_comments` text NOT NULL,
  `assigned_to` int(4) NOT NULL,
  `final_delivery_date` date NOT NULL,
  `final_request_category` varchar(50) NOT NULL,
  `updated_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `graphics_requeest_tl_updates`
--

INSERT INTO `graphics_requeest_tl_updates` (`request_id`, `tl_comments`, `assigned_to`, `final_delivery_date`, `final_request_category`, `updated_on`) VALUES
(0, '', 0, '0000-00-00', '', '2020-03-11 14:04:35'),
(16, 'A logo should be vibrant and it should be neat and very eye caching', 0, '2020-03-25', '12', '2020-03-11 14:13:09'),
(16, 'Create a Vibrant Logo should be very eye catching and contain animations', 0, '2020-03-25', '12', '2020-03-11 14:17:33'),
(16, 'Create a Vibrant Logo should be very eye catching and contain animations', 0, '2020-03-25', '12', '2020-03-11 14:19:23'),
(16, 'Create a Vibrant Logo should be very eye catching and contain animations', 0, '2020-03-25', '12', '2020-03-11 14:19:40'),
(16, 'Create a Vibrant Logo should be very eye catching and contain animations', 12, '2020-03-25', 'Aston', '2020-03-11 14:20:50'),
(16, 'Create a Vibrant Logo should be very eye catching and contain animations', 12, '2020-03-25', 'Aston', '2020-03-11 14:21:04'),
(16, 'Create a Vibrant Logo should be very eye catching and contain animations', 12, '2020-03-25', 'Aston', '2020-03-11 14:22:10'),
(16, 'Create a Vibrant Logo should be very eye catching and contain animations', 12, '2020-03-25', 'Aston', '2020-03-11 14:22:54'),
(16, 'Create a Vibrant Logo should be very eye catching and contain animations', 12, '2020-03-25', 'Aston', '2020-03-11 14:24:10');

-- --------------------------------------------------------

--
-- Table structure for table `graphics_requests`
--

CREATE TABLE `graphics_requests` (
  `request_id` int(4) NOT NULL,
  `requester_id` int(4) DEFAULT NULL,
  `request_title` varchar(100) DEFAULT NULL,
  `request_category` varchar(100) DEFAULT NULL,
  `request_description` text,
  `channel` varchar(50) NOT NULL,
  `resource` varchar(50) DEFAULT NULL,
  `exp_del_date` date DEFAULT NULL,
  `attachment_path` varchar(100) DEFAULT NULL,
  `request_status` enum('Open','Closed','Reopen','') NOT NULL DEFAULT 'Open',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `graphics_requests`
--

INSERT INTO `graphics_requests` (`request_id`, `requester_id`, `request_title`, `request_category`, `request_description`, `channel`, `resource`, `exp_del_date`, `attachment_path`, `request_status`, `created_on`) VALUES
(9, 1, 'Create A Aston ', 'av', 'Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', 'Colors', '0', '2020-03-31', NULL, 'Open', '2020-03-09 12:51:48'),
(12, 1, 'Baar Bar dekho Mtv India', 'film', 'asdfghjkl qwertyuio afghjkl;', 'mtv', '0', '2020-03-27', NULL, 'Open', '2020-03-09 12:59:14'),
(13, 1, 'Create a Title Montage Video', 'film', 'Lorem ipsum is a pseudo-Latin text used in web design, typography, layout, and printing in place of English to emphasise design elements over content. It\'s also called placeholder (or filler) text. It\'s a convenient tool for mock-ups.', 'Colors Kannada', '0', '2020-03-24', NULL, 'Open', '2020-03-09 12:54:48'),
(14, NULL, 'Mtv India Roadies Spotlight Banner', 'fiction', 'Create a Spotlight Banner of size 1920* 1680 for Roadies show.', 'Mtv India', '0', '2020-03-14', NULL, 'Open', '2020-03-11 11:09:35'),
(15, 1, 'Create A Big Boss Logo', 'non_fiction', 'Create a ILU for New Big Boss14. It should have a eye and Salmaan Khan', 'Colors Tv', '0', '2020-03-31', 'uploads/VIVO_BIG BOSS_GOLD & BLUE_THEME.jpg', 'Open', '2020-03-11 12:04:49'),
(16, 1, 'Create A Big Boss Logo', 'non_fiction', 'Create a ILU for New Big Boss14. It should have a eye and Salmaan Khan', 'Colors Tv', '12', '2020-03-31', 'uploads/VIVO_BIG BOSS_GOLD & BLUE_THEME.jpg', 'Open', '2020-03-11 12:06:55');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `project_id` int(4) NOT NULL,
  `title` varchar(100) NOT NULL,
  `jira_ticket` varchar(100) DEFAULT NULL,
  `description` text NOT NULL,
  `status` enum('open','closed',',') NOT NULL DEFAULT 'open',
  `role` varchar(15) NOT NULL,
  `user_id` varchar(25) NOT NULL,
  `added_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`project_id`, `title`, `jira_ticket`, `description`, `status`, `role`, `user_id`, `added_on`) VALUES
(8, 'Baar Bar dekho Mtv India', NULL, 'A microsite on MtvIndia which will have 3D model to be move on mouse scroll.\r\nA form will be there which will contain user infomation', 'open', 'designer_ui', 'varsha', '2020-02-25 14:11:53'),
(9, 'Baar Bar dekho Mtv India', 'http://jira.v18cc.com/browse/VDBS-276', 'Development of functionality where user will score the mouse and model will rotate accordingly', 'closed', 'developer', '4', '2020-02-25 14:12:58'),
(10, 'Design Campus Inc Website', NULL, 'Create a PSD file similar to totallyawesome', 'open', 'designer_ux', 'bhagyashree', '2020-02-25 14:16:15');

-- --------------------------------------------------------

--
-- Table structure for table `projects_hours_log`
--

CREATE TABLE `projects_hours_log` (
  `Id` int(4) NOT NULL,
  `project_id` int(4) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `user_id` varchar(25) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `total_hrs` int(2) DEFAULT NULL,
  `total_minutes` int(2) DEFAULT NULL,
  `status` enum('closed','open','','') DEFAULT NULL,
  `remarks` text,
  `updated_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects_hours_log`
--

INSERT INTO `projects_hours_log` (`Id`, `project_id`, `title`, `user_id`, `date`, `start_time`, `end_time`, `total_hrs`, `total_minutes`, `status`, `remarks`, `updated_on`) VALUES
(19, 9, 'Baar Bar dekho Mtv India', '4', '2020-03-02', '12:00:00', '02:00:00', 10, 0, 'open', 'Model Increase Size Remaining', '2020-03-02 16:12:44'),
(21, 9, 'Baar Bar dekho Mtv India', '4', '2020-03-02', '02:30:00', '04:40:00', 2, 10, 'closed', 'All changes done', '2020-03-02 16:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(25) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(30) DEFAULT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `username`, `email`, `role`, `password`) VALUES
(1, 'Hoshang Karanjekar', 'hoshang', 'hoshangkaranjekar@gmail.com', 'requester', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'Varsha Jain', 'varsha', 'varsha.jain@webdunia.net', 'designer_ui', '21232f297a57a5a743894a0e4a801fc3'),
(3, 'Deekshant Taranekar', 'deekshant', 'deekshant.taranekar@webdunia.net', 'project_lead', '21232f297a57a5a743894a0e4a801fc3'),
(4, 'Dharmendra Singh', 'dharmendra', 'dharmendra@webdunia.net', 'developer', '21232f297a57a5a743894a0e4a801fc3'),
(5, 'Harshit Verma', 'harshit', 'harshita.verma@webdunia.net', 'developer', '21232f297a57a5a743894a0e4a801fc3'),
(6, 'Hitendra Sharma', 'hitendra', 'hitendra.sharma@webdunia.net', 'infra_support', '21232f297a57a5a743894a0e4a801fc3'),
(7, 'Kapil Sharma', 'kapil', 'kapil.sharma@webdunia.net', 'designer_ui', '21232f297a57a5a743894a0e4a801fc3'),
(8, 'Bhagyshree Bargel', 'bhagyashree', 'bhagyashree.bargel@webdunia.net', 'designer_UX', '21232f297a57a5a743894a0e4a801fc3'),
(9, 'Saurabh Shukla', '', 'saurabh.shukla@gmail.com', 'project_lead', '21232f297a57a5a743894a0e4a801fc3'),
(12, 'Vipin Mendon', 'vipin', 'vipin.mendon@gmail.com', 'graphics_designer', '21232f297a57a5a743894a0e4a801fc3'),
(13, 'Bhagyesh Raut', 'bhagyesh', 'bhagyesh.raut@gmail.com', 'graphics_designer', '21232f297a57a5a743894a0e4a801fc3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `graphics_requeest_tl_updates`
--
ALTER TABLE `graphics_requeest_tl_updates`
  ADD KEY `request_id_fk` (`request_id`),
  ADD KEY `user_id_fk` (`assigned_to`);

--
-- Indexes for table `graphics_requests`
--
ALTER TABLE `graphics_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `user_id_fk` (`requester_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `projects_hours_log`
--
ALTER TABLE `projects_hours_log`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `graphics_requests`
--
ALTER TABLE `graphics_requests`
  MODIFY `request_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `project_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `projects_hours_log`
--
ALTER TABLE `projects_hours_log`
  MODIFY `Id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
