<?php 
  error_reporting(E_ERROR | E_WARNING | E_PARSE);
  session_start();
  if (!isset($_SESSION['email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Project</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style>
    .res {
      display: none;
    }
  </style>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
       $('input[type=radio][name=role]').change(function(){
         });
      
    })
  </script>
  <script>
  $(document).ready(function(){
    $(".resource_type").hide();
    $( "#role" ).change(function () {
        var role = $(this).val();
        $(".resource_type").show();
        console.log(role);
        if(role) {
            $.ajax({
                type:'POST',
                url: "populate.php",
                data:'role='+role,
                //dataType: 'Json',
                //data: {'role':role},
                success: function(html) {
                  console.log("Inside Success");
                  console.log(html);                    
                    $("#resource").html(html);                    
                },
                error:function(data){
                  console.log("Error");
                }
            });
        }else{
            $('select[name="resource"]').empty();
        }
    });
  })
    </script>
</head>
<body>
  <div class="header">
    <h2>Assign Project</h2>
  </div>
  <div class="content">
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['email'])) : ?>
      <p class="welcome">Welcome <strong><?php echo $_SESSION['fullname']; ?></strong>
      <a href="index.php?logout='1'" style="color: red; float: right;">logout</a> </p>
      <br>
      <a class="btn btn-primary" href="register.php" role="button" style="margin-left: 0px;">Add User</a>
      <a class="btn btn-primary" href="add_project.php" role="button" style="margin-left:0px; ;">Assign Project</a>
      <a class="btn btn-primary" href="view_report.php" role="button" style="float: right;">View Report</a>
      </br>
      <br>
      <form method="post" action="add_project_process.php">
        <?php //include('errors.php'); ?>
        <div class="input-group">
          <label style="margin-left: 0px;">Title</label>
          <input type="text" name="title" value="<?php echo $title; ?>" style="margin-left: 0px;" required> 
        </div>
        <div class="input-group">
          <label style="margin-left: 0px;">Jira Ticket No</label>
          <input type="text" name="jira_ticket" value="<?php echo $jira_ticket; ?>" style="margin-left: 0px;" required>
        </div>
        <div class="input-group" style="margin-left: 0px;">
          <label style="margin-left: 0px;">Description</label>
          <textarea name="description" value="<?php echo $description; ?>" rows="6" cols="45" required></textarea>
        </div>
        <div class="input-group">
          <label style="margin-left: 0px;">Role</label>
          <select name="role" style="" id="role" required>
              <option value="">Select Role</option>
              <option value="designer_ui">Designer UI</option>
              <option value="designer_ux">Designer UX</option>
              <option value="developer">Developer</option>
              <option value="tester">QA/ Tester</option>
              <option value="seo">SEO</option>
              <option value="operation">Operation</option>
              <option value="infra_support">Infra Support</option>        
              <option value="project_lead">Project Lead</option>
          </select>
        </div>
        <div class="resource_type">
          <label style="margin-left: 0px;">Resource</label><br>     
             <select id="resource" name="resource">
                  <option>Select</option>
            </select>
        </div>          
        <div class="input-group">
          <button type="submit" class="btn" name="assign_prj">Assign Project</button>
        </div>
      </form>
    <?php endif ?>
  </div>
</body>
</html>