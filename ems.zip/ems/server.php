<?php
session_start();
error_reporting(E_ALL); 
ini_set('display_errors', TRUE);
// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'ems');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $fullname = mysqli_real_escape_string($db, $_POST['fullname']);
  #$username = mysqli_real_escape_string($db, $_POST['username']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $role = mysqli_real_escape_string($db, $_POST['role']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($fullname)) { array_push($errors, "Fullname is required"); }
  #if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
	     array_push($errors, "The two passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  //$user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
  $user_check_query = "SELECT `email` FROM users WHERE email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
    if ($user) 
    { // if user exists
      if ($user['email'] === $email) {
        array_push($errors, "Email already exists");
    }
    
  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	$password = md5($password_1);//encrypt the password before saving in the database

  	$query = "INSERT INTO users (fullname, email, role, password) 
  			  VALUES('$fullname' , '$email', '$role', '$password')";
    echo $query;
  	mysqli_query($db, $query);
  	$_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: index.php');
  }
}

// LOGIN USER
if (isset($_POST['login_user'])) {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($email)) {
    array_push($errors, "Email is required");
  }
  if (empty($password)) {
    array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
    $password = md5($password);
    $query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    echo $query;
    $results = mysqli_query($db, $query);
    print_r($results);
    if (mysqli_num_rows($results) == 1) {
      echo "Here";
      $_SESSION['email'] = $email;
      $row = mysqli_fetch_assoc($results);
      $_SESSION['role'] = $row['role'];
      $_SESSION['fullname'] = $row['fullname'];
      $_SESSION['success'] = "You are now logged in";

      print_r($row);
      echo $_SESSION['role'];
      echo $_SESSION['fullname'];
      #header('location: index.php');
      echo "<script type='text/javascript'> window.location = 'index.php'; </script>";
    }else {
      array_push($errors, "Wrong email/password combination");
    }
  }
}

?>