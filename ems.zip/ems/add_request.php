<?php 
  error_reporting(E_ERROR | E_WARNING | E_PARSE);
  session_start();
  if (!isset($_SESSION['email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Assign Request</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style>
    .res {
      display: none;
    }
  </style>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
       $('input[type=radio][name=role]').change(function(){
         });
      
    })
  </script>
  <script>
  $(document).ready(function(){
    $(".resource_type").hide();
    $( "#role" ).change(function () {
        var role = $(this).val();
        $(".resource_type").show();
        console.log(role);
        if(role) {
            $.ajax({
                type:'POST',
                url: "populate.php",
                data:'role='+role,
                //dataType: 'Json',
                //data: {'role':role},
                success: function(html) {
                  console.log("Inside Success");
                  console.log(html);                    
                    $("#resource").html(html);                    
                },
                error:function(data){
                  console.log("Error");
                }
            });
        }else{
            $('select[name="resource"]').empty();
        }
    });
  })
    </script>
  
</head>
<body>
  <div class="header">
    <h2>Assign Graphics Request</h2>
  </div>
  <div class="content">
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['email'])) : ?>
      <p class="welcome">Welcome <strong><?php echo $_SESSION['fullname']; ?></strong>
      <a href="index.php?logout='1'" style="color: red; float: right;">logout</a> </p>
      <br>
      <a class="btn btn-primary" href="register.php" role="button" style="margin-left: 0px;">Add User</a>
      <a class="btn btn-primary" href="add_project.php" role="button" style="margin-left:0px; ;">Add Project</a>

      <a class="btn btn-primary" href="view_report.php" role="button" style="float: right;">View Report</a>
      </br>
      <br>
      <form method="post" action="add_request_process.php" enctype="multipart/form-data">
        <?php include('errors.php'); ?>
        <div class="input-group">
          <label style="margin-left: 0px;">Job Title</label>
          <input type="text" name="title" value="<?php echo $title; ?>" style="margin-left: 0px;" required> 
        </div>
        <div class="input-group">
          <label style="margin-left: 0px;">Category</label>
          <select name="category" style="" id="category" required>
              <option value="">Select Job Category</option>
              <option value="fiction">Fiction</option>
              <option value="non_fiction">Non Fiction</option>
              <option value="film">Film</option>
              <option value="av">AV</option>
              <option value="others">Others</option>
          </select>
        </div>
        <div class="input-group" style="margin-left: 0px;">
          <label style="margin-left: 0px;">Description</label>
          <textarea name="description" value="<?php echo $description; ?>" rows="6" cols="45" required></textarea>
        </div>
        <div class="input-group">
          <label style="margin-left: 0px;">Channel</label>
          <select name="channel" style="" id="channel" required>
              <option value="">Select Channel</option>
              <option value="Colors Bangla">Colors Bangla</option>
              <option value="Colors Marathi">Colors Marathi</option>
              <option value="Colors Kannada">Colors Kannada</option>
              <option value="Colors Gujarati">Colors Gujarati</option>
              <option value="Colors Tv">Colors Tv</option>
              <option value="Mtv India">Mtv India</option>
              <option value="Colors Gujarati Cinema">Colors Gujarati Cinema</option>        
              <option value="Colors Super">Colors Super</option>
          </select>
        </div>
        <br>  
        <div class="input-group">
           <div class="custom-file" style="margin-left: 0px;">
                <label class="custom-file-label" for="inputfile" style="margin-left: 0px;">Choose file</label>
                <input type="file" class="custom-file-input" id="input_file" name="input_file" aria-describedby="" style="margin-left: 0px;">
            </div>
        </div>
        <br>  
        <div class="input-group" style="margin-left: 0px;">
            <label for="birthday" style="margin-left: 0px;">Expected Delivery Date</label>
            <input type="date" id="exp_del_date" name="exp_del_date" style="margin-left: 0px;">
        </div>        
        <div class="input-group">
          <button type="submit" class="btn" name="assign_request">Assign Request</button>
        </div>
      </form>
    <?php endif ?>
  </div>
</body>
</html>