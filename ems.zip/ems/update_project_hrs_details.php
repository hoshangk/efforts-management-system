<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
// initializing variables
$title = "";
$date  = "";
$start_time = "";
$end_time = "";
$status = "";
$remarks = "";
$errors = array(); 
$log_file = 'error.txt';
// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'ems');

// REGISTER USER
if (isset($_POST['update_hrs'])) {
  // receive all input values from the form
  $email = $_SESSION['email'];
  $project_id = $_SESSION['project_id'];
  // echo $project_id;
  $title = mysqli_real_escape_string($db, $_POST['title']);
  $date = mysqli_real_escape_string($db, $_POST['date']);
  $start_time = mysqli_real_escape_string($db, $_POST['start_time']);
  $end_time = mysqli_real_escape_string($db, $_POST['end_time']);
  $status = mysqli_real_escape_string($db, $_POST['status']);
  $remarks = mysqli_real_escape_string($db, $_POST['remarks']);

  // echo $date;
   // echo $start_time;
   // echo $end_time;
   // echo "<br>";
   // $minutes = abs((strtotime($start_time) - strtotime($end_time))/60);
   // echo $minutes."<br>";
   // $mins = $minutes%60;
   // $hrs = intdiv($minutes, 60);
   // echo $mins."<br>";
   // echo $hrs."<br>";
  // echo $remarks;
  // echo $status;
  // file_put_contents($log_file,"Inside isset", date("Y-m-d h:i:sa"));
  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($start_time)) { array_push($errors, "Start Time is required"); }
  if (empty($end_time)) { array_push($errors, "End Time is required"); }
  if (empty($status)) { array_push($errors, "Status is required"); }
  
  //Calculate Hours here from Start Time & End Time
  
  $query_id = "select id from users where `email` = '$email'";
  $res_query_id = mysqli_query($db, $query_id);
        if(mysqli_num_rows($res_query_id)==1){
          $row = mysqli_fetch_assoc($res_query_id);
          $user_id = $row['id'];
        }
  // echo "--User id---".$user_id;
  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	  	$query = "INSERT INTO `projects_hours_log` 
              (`Id`,`project_id`, `title`, `user_id`, `date`, `start_time`, `end_time`, `total_hrs`, `total_minutes`, 
              `status`, `remarks`, `updated_on`) 
                  VALUES 
              (NULL,'$project_id', '$title', '$user_id','$date', '$start_time', '$end_time', '$hrs', '$mins', 
              '$status', '$remarks', current_timestamp())";
        echo $query;           
      	$res_query = mysqli_query($db, $query);
        if(mysqli_affected_rows($db)<=0){
          $_SESSION['error'] = 'Data Update Failed';
          header('location: update_project_hours.php');
        }
        else{
            $_SESSION['success'] = "Project Hours Updated Successfully";
            header('location: update_project_hours.php');
            if($status == 'closed'){
                $update_status_query = "UPDATE `projects` set `status` = '$status' where `project_id`='$project_id'";
                echo $update_status_query;
                $res_update_status_query = mysqli_query($db, $update_status_query);
          }      
    }  	
  }
}

?>