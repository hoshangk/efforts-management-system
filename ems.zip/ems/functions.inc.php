
<?php

function get_user_id($email, $db){

	$get_id  = "select `id` from users where `email` = '$email'";
	echo $get_id;
	$res_get_id = mysqli_query($db, $get_id);
	if(mysqli_num_rows($res_get_id) == 1){
		$row = mysqli_fetch_assoc($res_get_id);
		$user_id = $row['id'];
	}
	else{
		$user_id = "None";
	}

	return $user_id;

}




?>