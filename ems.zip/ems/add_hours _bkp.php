<?php 
  session_start();
  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
  $db = mysqli_connect('localhost', 'root', '', 'ems');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Hours</title>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="http://cdn.jsdelivr.net/timepicker.js/latest/timepicker.min.js"></script>
  <link href="http://cdn.jsdelivr.net/timepicker.js/latest/timepicker.min.css" rel="stylesheet"/>
</head>
<script>    
  function updateHours(){
        var $time1 = document.getElementById("s_time").value;
        var $time2 = document.getElementById("e_time").value;
        var dtStart = new Date("7/20/2015 " + $time1);
        var dtEnd = new Date("7/20/2015 " + $time2);
        var diff = (dtEnd - dtStart);
        console.log(diff);
        var min = diff/60000;
        console.log(min);
        console.log(timeConvert(min));
        document.getElementById("h_spent").value = timeConvert(min);
   };
    
  function timeConvert(n) {
    var num = n;
    var hours = (num / 60);
    var rhours = Math.floor(hours);
    var minutes = (hours - rhours) * 60;
    var rminutes = Math.round(minutes);
    return num + " minutes = " + rhours + " hour(s) and " + rminutes + " minute(s).";
    }  
 
   function showId(id){
    console.log("FUnction Called");
    console.log(id);
   }
 
</script>
<body>

  <form action="update_details.php" method="post">
    <table class="table table-hover">
      <thead>
        <th>Project Title</th>
        <th>Date</th>
        <th>Start Time</th>
        <th>End Time</th>
        <th>Hours Spend</th>
        <th>Status</th>
        <th>Remark/ Work Done</th>
        <th>Action</th>
      </thead>
      <tbody>
        <?php
            $resource = $_SESSION['username'];
            $qry = "SELECT * FROM `projects` WHERE `resource` = '$resource' limit 1" ;
            $result = mysqli_query($db, $qry);
            for($i=1; $i<=mysqli_num_rows($result); $i++)
            {
              $row = mysqli_fetch_assoc($result);
            ?>
              <tr>
                <td><?php echo $row['title']; ?></td>
                <td><?php echo date("Y-m-d"); ?></td>
                <td><input type="time" id="s_time" placeholder="Start Time" onchange="showId(this.id);"></td>
                <td><input type="time" id="e_time" placeholder="End Time" onchange="updateHours();"></td>
                <td><input type="text" name="hours_spent" value="" id="h_spent"></td>
                <td>
                  <select id="status" name="status">
                    <option value="open">Open</option>
                    <option value="closed">Closed</option>
                  </select>
                </td>
                <td><input type="text" name="remark" value=""></td>
                <td><input type="submit" name="update_hrs" value="Update"></td>
              </tr>
            <?php
            }
        ?>
      </tbody>
    </table>

  </form>

</body>
</html>