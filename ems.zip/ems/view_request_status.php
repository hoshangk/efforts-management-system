<?php 
  session_start();
  if (!isset($_SESSION['email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }
  $db = mysqli_connect('localhost', 'root', '', 'ems');
?>
<!DOCTYPE html>
<html>
<head>
  <title>View Requests</title>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>  
  <script src="http://cdn.jsdelivr.net/timepicker.js/latest/timepicker.min.js"></script>
  <link href="http://cdn.jsdelivr.net/timepicker.js/latest/timepicker.min.css" rel="stylesheet"/>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <h2>G-Track -- View Requests</h2>
</div>
<div class="content">
  <?php //echo $_SESSION['username']; ?>
  <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <?php  if (isset($_SESSION['email']) && $_SESSION['role'] == 'requester') : ?>
      <p class="welcome">Welcome <strong><?php echo $_SESSION['fullname']; ?></strong>
      <a href="index.php?logout='1'" style="color: red; float: right;">logout</a> </p>
      <br>
      <?php
      if (($_SESSION['role']) == 'requester')
      { ?>
          <a class="btn btn-primary" href="add_request.php" role="button" style="margin-left: 0px;">Add Graphics Requests</a>
          <a class="btn btn-primary" href="view_request_status.php" role="button" style="float: right;">View Report</a>
      <?php } ?>
      <br>
      <br>
      <form action="request_detail.php" method="post" id="hrs_frm">
        <table id="hrs_table">
          <thead style="background-color: #5F9EA0;">
            <th scope="col">Sr No.</th>
            <th scope="col">Request Title</th>
            <th scope="col">Request Description</th>
            <th scope="col">Added On</th>
            <th scope="col">Assigned To</th>       
            <th scope="col">Channel</th>
            <th scope="col">Category</th>
            <th scope="col">Action</th>
          </thead>
          <tbody>
            <?php
                $email = $_SESSION['email'];
                // $qry = "SELECT * FROM `projects` WHERE `resource` = '$resource' and `status` = 'open'" ;
                $qry = "SELECT * FROM `projects` WHERE `user_id` = (select id from users where `email` = '$email')" ;
                #echo $qry;
                $result = mysqli_query($db, $qry);
                for($i=1; $i<=mysqli_num_rows($result); $i++)
                {
                  $row = mysqli_fetch_assoc($result);
                  $_SESSION['project_id'] = $row['project_id'];
                  // echo $_SESSION['project_id'];
                ?>
                  <tr>
                    <td><?php echo $i; ?></td>
                    <td><input type="text" name="title" value="<?php echo $row['title']; ?>" style="height: 25px; border: none;" readonly></td>
                    <td><input type="text" name="date" id="date" value="<?php echo date("Y-m-d"); ?>" readonly></td>
                    <td><input type="time" id="<?php echo 's_time_'.$i; ?>" name='start_time' value="<?php echo 's_time_'.$i; ?>" style="height: 25px; width: 100px;"></td>
                    <td><input type="time" id="<?php echo 'e_time_'.$i; ?>" name='end_time' value="<?php echo 'e_time_'.$i; ?>" style="height: 25px;"></td>
                    
                    <td>
                      <select id="status" name="status" style="height: 25px;">
                        <option value="open">Open</option>
                        <option value="closed">Closed</option>
                      </select>
                    </td>
                    <td><input type="text" name="remarks" value="" style="height: 25px;"></td>
                    <td><input type="submit" name="update_hrs" value="Update" class="btn btn-success"></td>

                  </tr>
                <?php
                }
            ?>
          </tbody>
        </table>
      </form>
    <?php endif ?>
  </div>
</body>
</html>