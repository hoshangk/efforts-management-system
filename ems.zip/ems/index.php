<?php 
  session_start(); 

  if (!isset($_SESSION['email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
	<h2>Effors Management System</h2>
</div>
<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['email'])) : ?>
    	<p class="welcome">Welcome <strong><?php echo $_SESSION['fullname'];?> </strong>
        <?php if(isset($_SESSION['success'])) echo $_SESSION['success']; ?>
      <a href="index.php?logout='1'" style="color: red; float: right;">logout</a> </p>
      <br>
      <br>
      <?php
      if (($_SESSION['role']) == 'admin' || $_SESSION['role'] == 'project_lead')
      { ?>
          <a class="btn btn-primary" href="add_project.php" role="button" style="margin-left: 0px;">Assign Project</a>
          <a class="btn btn-primary" href="assign_graphics_request.php" role="button" style="margin-left: 0px;">Assign Graphics Requests</a>
          <a class="btn btn-primary" href="register.php" role="button" style="margin-left: 0px;">Add User</a>
          <a class="btn btn-primary" href="view_report.php" role="button" style="float: right;">View Report</a>
      <?php }
      else if (($_SESSION['role']) == 'requester')
      {?>
          <a class="btn btn-primary" href="add_request.php" role="button" style="margin-left: 0px;">Add Graphics Request</a>
          <a class="btn btn-primary" href="view_request_status.php" role="button" style="margin-left: 0px;">View Requests</a>

      <?php }
      else
      { ?>
          <a class="btn btn-primary" href="update_project_hours.php" role="button" style="margin-left: 0px;">Update Worklog</a>
      <?php }
      ?>
    <?php endif ?>

</div>		
</body>
</html>