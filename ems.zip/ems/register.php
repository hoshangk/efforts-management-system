<?php include('server.php');  error_reporting(E_ERROR | E_WARNING | E_PARSE);?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Efforts Management System - Register</h2>
  </div>
  <div class="content">
	<?php  if (isset($_SESSION['email']))
      { ?>
        <p class="welcome">Welcome <strong><?php echo $_SESSION['fullname']; ?></strong>
        <a href="index.php?logout='1'" style="color: red; float: right;">logout</a>
        </p>
        <br><br>
        <a class="btn btn-primary" href="register.php" role="button" style="margin-left:0px;">Add User</a>
        <a class="btn btn-primary active" href="add_project.php" role="button" style="margin-left:0px;" >Assign Project</a>
        <a class="btn btn-primary" href="view_report.php" role="button" style="margin-left:0px;">View Report</a>
        <h2 style="text-align: center;">Add User</h2>        
   <?php  }?> 
  <form method="post" action="register.php" style="border: none;">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  	  <label>Full Name</label>
  	  <input type="text" name="fullname" value="<?php echo $fullname; ?>">
  	</div>
    <!--<div class="input-group">
      <label>Username</label>
      <input type="text" name="username" value="<?php //echo $username; ?>">
    </div>-->
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php echo $email; ?>">
  	</div>
    <div class="input-group">
      <label>Role</label>
      <select name="role" style="margin-left: 35%;" required>
          <option value="">Select Role</option>
          <option value="designer_ui">Designer UI</option>
          <option value="designer_ux">Designer UX</option>
          <option value="developer">Developer</option>
          <option value="tester">QA/ Tester</option>
          <option value="infra_support">Infra Support</option>        
          <option value="project_lead">Project Lead</option>
          <option value="requester">Requester</option>
      </select>
    </div>
    <!--
    <div class="role" style="margin-left: 35%;">
      <input type="radio" id="developer" name="role" value="developer" checked>
      <label for="developer">Developer</label>
      <input type="radio" id="designer" name="role" value="designer">
      <label for="designer">Designer</label>
    </div>
  -->
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Register</button>
  	</div>
  	<p>
  		Already a member? <a href="login.php">Sign in</a>
  	</p>
  </form>
  </div>
</body>
</html>