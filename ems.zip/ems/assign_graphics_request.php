<?php 
  session_start();
  if (!isset($_SESSION['email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }
  $db = mysqli_connect('localhost', 'root', '', 'ems');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Assign Requests</title>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>  
  <script src="http://cdn.jsdelivr.net/timepicker.js/latest/timepicker.min.js"></script>
  <link href="http://cdn.jsdelivr.net/timepicker.js/latest/timepicker.min.css" rel="stylesheet"/>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <h2>G-Track -- Assign Requests</h2>
</div>
<div class="content">
  <?php //echo $_SESSION['username']; ?>
  <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <?php  if (isset($_SESSION['email'])): ?>
      <p class="welcome">Welcome <strong><?php echo $_SESSION['fullname']; ?></strong>
      <a href="index.php?logout='1'" style="color: red; float: right;">logout</a> </p>
      <br>
      <?php
      if (($_SESSION['role']) == 'project_lead')
      { ?>
          <!--<a class="btn btn-primary" href="view_request_status.php" role="button" style="float: right;">Assign Graphics Requests</a>-->
      <?php } ?>
      <br>
      <br>
      <form action="request_detail.php" method="post" id="hrs_frm">
        <table id="hrs_table">
          <thead style="background-color: #5F9EA0;">
            <th scope="col">Sr No.</th>
            <th scope="col">Request Title</th>
            <th scope="col">Requester Name</th>
            <th scope="col">Request Description</th>
            <th scope="col">Category</th>            
            <th scope="col">Added On</th>
            <th scope="col">Channel</th>
            <th scope="col">Action</th>
            <th scope="col">Status</th>
          </thead>
          <tbody>
            <?php
                $email = $_SESSION['email'];
                // $qry = "SELECT * FROM `projects` WHERE `resource` = '$resource' and `status` = 'open'" ;
                $qry = "SELECT * FROM `graphics_requests`";
                #echo $qry;
                $result = mysqli_query($db, $qry);
                for($i=1; $i<=mysqli_num_rows($result); $i++)
                {
                  $row = mysqli_fetch_assoc($result);
                  $_SESSION['request_id'] = $row['request_id'];
                  $requester_id = $row['requester_id'];
                  $get_requester_name = "select fullname from users where id = '$requester_id'";
                  $res_requester_name = mysqli_query($db, $get_requester_name);
                  $rr = mysqli_fetch_assoc($res_requester_name);
                  $requester_name = $rr['fullname'];
                  $_SESSION['requester_name'] = $requester_name;
                  $_SESSION['request_title'] = $row['request_title'];
                  $_SESSION['request_description'] = $row['request_description'];
                  $_SESSION['exp_delivery_date'] = $row['exp_del_date'];
                  $_SESSION['channel'] = $row['channel'];
                  $_SESSION['category'] = $row['request_category'];
                  $_SESSION['attachment_path'] = $row['attachment_path'];
                ?>
                  <tr>
                    <td><?php echo $i; ?></td>
                    <td><textarea name="request_title"><?php echo $row['request_title']; ?></textarea></td>
                    <td><input type="text" name="requester_name" value="<?php echo $requester_name; ?>" style="height: 25px; border: none;" readonly></td>
                    <!--<td><input type="text" name="request_description" value="<?php echo $row['request_description']; ?>" style="height: 25px; border: none;" readonly></td>-->
                    <td><textarea name='request_description'><?php echo $row['request_description']; ?></textarea></td>
                    <td><input type="text" name="request_category" value="<?php echo $row['request_category']; ?>" style="height: 25px; border: none;" readonly></td>
                    <td><input type="text" name="date" id="date" value="<?php echo date("Y-m-d"); ?>" readonly></td>              
                    <td><input type="text" name="channel" value="<?php echo $row['channel']; ?>" style="height: 25px; border: none;" readonly></td>                        
                    <td><label name="edit_request" value=""><a href='edit_graphics_request.php'>Edit Request</a></td>
                    <td><label name="status"><?php echo $row['request_status']; ?></label></td>
                  </tr>
                <?php
                }
            ?>
          </tbody>
        </table>
      </form>
    <?php endif ?>
  </div>
</body>
</html>