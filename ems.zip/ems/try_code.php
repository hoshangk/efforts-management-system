<thead style="background-color: #5F9EA0;">
            <th>Id</th>
            <th>Title</th>
            <th>Description</th>
            <th>Role</th>
            <th>Resource</th>
            <th>Created on</th>
            <th>Last Modified</th>
            <th>Total Hrs Spent</th>
            <th>Remarks</th>
            <th>Status</th>
          </thead>
          <tbody>
            <?php
               $sql = "select p.project_id, p.title, p.description, p.role, p.resource, p.added_on, max(d.date) as last_modified, concat((sum(d.total_hrs)+sum(d.total_minutes) div 60),' Hrs ',sum(d.total_minutes)%60,' Mins') as total_time_in_hrs, d.remarks as last_remarks, d.status\n"
                . "from projects p inner join projects_hours_log d\n"
                . "ON\n"
                . "p.project_id = d.project_id\n"
                . "group by p.project_id";
                // echo($sql);
                $result = mysqli_query($db, $sql);
                // print_r($result);
                for($i = 0; $i < mysqli_num_rows($result); $i++){
                  $row = mysqli_fetch_assoc($result);
            ?>
            <tr>
                <td><?php echo $row['project_id']; ?></td>
                <td><?php echo $row['title']; ?></td>
                <td><?php echo $row['description']; ?></td>
                <td><?php echo $row['role']; ?></td>
                <td><?php echo $row['resource']; ?></td>
                <td><?php echo $row['added_on']; ?></td>
                <td><?php echo $row['last_modified']; ?></td>
                <td><?php echo $row['total_time_in_hrs']; ?></td>
                <td><?php echo $row['last_remarks']; ?></td>
                <td><?php echo $row['status']; ?></td>
            </tr>
            <?php } ?>           
          </tbody>        



          function populate(role, resource){
        role = document.getElementById(s1);
        resource = document.getElementById(s2);
        s2.innerHTML = "";
        if( role.value="developer"){

        }
        else if(ole.value="developer"){

        }
        else if(ole.value="developer"){

        }
        else if(ole.value="developer")
        {

        }
        else if(ole.value="developer")
        resourceArry

    }

     var items = [{ name: 'Dharmendra', role: 'developer' },
                 { name: 'Harshita', role: 'developer' },
                 { name: 'Mustafa', role: 'developer' },
                 { name: 'Bhagyashree', role: 'designer' },
                 { name: 'Hitendra', role: 'operation' }];
     $(function () {
         //$('[name="role"]').change(function (a, b) {
         $('#resource_type').change(function (a, b) {
            $(".res").show();
             $('#resource option').remove();
             var id = a.target.id;
             console.log(id);
             var options = [];
             if (id == 'developer' && a.target.checked) {
                 options = getItems('developer')
             }
             else if (id == 'designer' && a.target.checked) {
                 options = getItems('designer')
             }
             else
             {
                options = getItems('operation')
             }
             $('#resource').append(options.join(''));
            
         });
     });

     function getItems(resource) {
      console.log("Function Called");
      console.log(resource)
         var options = [];
         for (var i = 0; i < items.length; i++) {
             var item = items[i];
             console.log(item.role)
             if (item.role == resource) {
                 options.push('<option value="' + item.name + '"> ' + item.name + ' </option>');
             }
         }
         return options;