<?php
include_once('functions.inc.php');
session_start();
 error_reporting(E_ERROR | E_WARNING | E_PARSE);
// initializing variables
$request_title = "";
$request_description  = "";
$request_category = "";
$channel = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'ems');

// REGISTER USER
if (isset($_POST['update_request'])) {
  echo "Inside Process";
  // receive all input values from the form
  $request_id = $_SESSION['request_id'];
  $assigner_comments = mysqli_real_escape_string($db, $_POST['assigner_comments']);
  $updated_category = mysqli_real_escape_string($db, $_POST['updated_category']);
  $final_request_del_date = mysqli_real_escape_string($db, $_POST['final_request_del_date']);
  $resource = mysqli_real_escape_string($db, $_POST['resource']);

    echo $request_id."<br>";
    echo $assigner_comments."<br>";
    echo $updated_category."<br>";
    echo $final_request_del_date."<br>";
    echo $resource."<br>";
  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($request_id)) { array_push($errors, "Id is required"); }
  if (empty($assigner_comments)) { array_push($errors, "Assigner Comments is required"); }
  if (empty($updated_category)) { array_push($errors, "Category is NOt Updated"); }
  if (empty($final_request_del_date)) { array_push($errors, "Final Date is Not Updated"); }
  if (empty($resource)) { array_push($errors, "Resource is required"); }
  
  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {     
    $sql = "INSERT INTO `graphics_requeest_tl_updates` (`request_id`, `tl_comments`, `assigned_to`, `final_delivery_date`, `final_request_category`, `updated_on`) VALUES ('$request_id', '$assigner_comments','$resource', '$final_request_del_date', '$updated_category', CURRENT_TIMESTAMP)";
    echo $sql;
    // exit;
  	$ins_request = mysqli_query($db, $sql);
    if($ins_request){
      $update_resource = "update `graphics_requests` set `resource`= '$resource' where `request_id`='$request_id'";
      echo $update_resource;
      $res_update_resource = mysqli_query($db, $update_resource);
      if($res_update_resource){
        $_SESSION['success'] = "Request Submitted Successfully";
      }
      {
        $_SESSION['success'] = "Failed To update Resource--Rollback";
      }
    }
    else{
        $_SESSION['success'] = "Request Not Submitted";
    }
  	header('location: index.php');
  }
}

?>