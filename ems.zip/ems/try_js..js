$(document).ready(function(){
    var s_time = new TimePicker('s_time', {
      lang: 'en',
      theme: 'dark'
      });
      s_time.on('change', function(evt1) {
        
        var value1 = (evt1.hour || '00') + ':' + (evt1.minute || '00');
        evt1.element.value = value1;

      });     
  })

  $(document).ready(function() {
    var e_time = new TimePicker('e_time', {
      lang: 'en',
      theme: 'dark'
      });
      e_time.on('change', function(evt2) {
        
        var value2 = (evt2.hour || '00') + ':' + (evt2.minute || '00');
        evt2.element.value = value2;

      });
  })
  function myFunction() {
    var x = document.getElementById("s_time").value;
    var y = document.getElementById("e_time").value;
    console.log(x);
    console.log(y);
    var duration = duration(y.diff(x));
    console.log(duration);
    console.log("-------");
  }

  <script>    
  function updateHours(){
        // console.log(s_time_$i)
        // arr = id.split('-');
        // var s_time = arr[0];
        // var e_time = arr[1];
        // console.log(s_time);
        // console.log(e_time);
        var $time1 = document.getElementById("s_time_$i").value;
        var $time2 = document.getElementById("e_time_$i").value;

        var dtStart = new Date("7/20/2015 " + $time1);
        var dtEnd = new Date("7/20/2015 " + $time2);
        var diff = (dtEnd - dtStart);
        console.log(diff);
        var min = diff/60000;
        console.log(min);
        console.log(timeConvert(min));
        document.getElementById("h_spent").value = timeConvert(min);
   };
    
  function timeConvert(n) {
    var num = n;
    var hours = (num / 60);
    var rhours = Math.floor(hours);
    var minutes = (hours - rhours) * 60;
    var rminutes = Math.round(minutes);
    return num + " minutes = " + rhours + " hour(s) and " + rminutes + " minute(s).";
    }  
 
   function showId(id){
    console.log("FUnction Called");
    console.log(id);
     arr = id.split('-');
        var s_time = arr[0];
        var e_time = arr[1];
    console.log(s_time);
    console.log(e_time);
   }
 
</script>