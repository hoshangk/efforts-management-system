<?php 
  session_start();
  if (!isset($_SESSION['email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }
  $db = mysqli_connect('localhost', 'root', '', 'ems');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Assign Requests</title>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>  
  <script src="http://cdn.jsdelivr.net/timepicker.js/latest/timepicker.min.js"></script>
  <link href="http://cdn.jsdelivr.net/timepicker.js/latest/timepicker.min.css" rel="stylesheet"/>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style>
      * {
        box-sizing: border-box;
      }

      /* Create two equal columns that floats next to each other */
      .column {
        float: left;
        width: 50%;
        padding: 10px;
        height: auto; /* Should be removed. Only for demonstration */
      }

      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      td {
        width: 50%;
        padding: 10px;
        border: none;
        text-align: left;
      }
      input[type="submit"]{
        height: 25px;
      }
      </style>
</head>
<body>
<div class="header">
    <h2>G-Track -- Assign Requests</h2>
</div>
<div class="content">
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <?php  if (isset($_SESSION['email'])): ?>
      <p class="welcome">Welcome <strong><?php echo $_SESSION['fullname']; ?></strong>
      <a href="index.php?logout='1'" style="color: red; float: right;">logout</a> </p>
      <br>
      <form action="edit_graphics_request_process.php" method="post">
      <div class="row">
        <div class="column" style="background-color:">
          <h2 align="center">Request Details</h2><br>
          <table border="0">
            <tr>
              <td>Request ID</td>
              <td><?php echo $_SESSION['request_id']; ?></td>
            </tr>
            <tr>
              <td>Request Title</td>
              <td><?php echo $_SESSION['request_title']; ?></td>
            </tr>
            <tr>
              <td>Requester Name</td>
              <td><?php echo $_SESSION['requester_name']; ?></td>
            </tr>
             <tr>
              <td>Request Description</td>
              <td><?php echo $_SESSION['request_description']; ?></td>
            </tr>
             <tr>
              <td>Channel</td>
              <td><?php echo $_SESSION['channel']; ?></td>
            </tr>
             <tr>
              <td>Request Category</td>
              <td><?php echo $_SESSION['category']; ?></td>
            </tr>
            <tr>
              <td>Request Delivery Date</td>
              <td><?php echo $_SESSION['exp_delivery_date']; ?></td>
            </tr>
            <tr>
              <td>Attached Files</td>
              <td><a href="<?php echo $_SESSION['attachment_path'] ?>">Attachment</td>
            </tr>
             
          </table>
        </div>
        <div class="column" style="background-color:">
          <h2 align="center">Update Request</h2>
          <br>
          <table>
            <tr>
              <td>Assigner Comments</td>
              <td><textarea name="assigner_comments" cols="60" rows="5"></textarea></td>
            </tr>
            <tr>
              <td>Request Category</td>
              <td><input type="text" name="updated_category"></td>
            </tr>
            <tr>
              <td>
                Final Delivery Date
              </td>
              <td>
                <input type="date" name="final_request_del_date">
              </td>              
            </tr>
            <tr>
              <td>Assign To</td>
              <td>
                <select name="resource">
                  <option>Select Resource</option>
                  <?php
                   $sel_resource = "select fullname, id from users where role='graphics_designer'";
                   echo $sel_resource;
                   $res_res = mysqli_query($db, $sel_resource);
                   for($i =0; $i<mysqli_num_rows($res_res); $i++){
                      $rr = mysqli_fetch_assoc($res_res);
                      $user_id = $rr['id'];
                      $fullname = $rr['fullname'];
                      ?>
                      <option value="<?php echo $rr['id'];?>"><?php echo $rr['fullname'];?></option>
                   <?php }
                   ?>                  
                </select>
              </td>
            </tr>
            <tr>
              <td colspan="2"><input type="submit" name="update_request" value="Update Request" class="btn btn-success"></td>
            </tr>
          </table>
        </div>
      </div>
      </form>
      <?php endif ?>
  </div>
</body>
</html>