<?php
#session_start();
 error_reporting(E_ERROR | E_WARNING | E_PARSE);
// initializing variables
$title = "";
$description  = "";
$role = "";
$resource = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'ems');

// REGISTER USER
if (isset($_POST['assign_prj'])) {
  // receive all input values from the form
  $title = mysqli_real_escape_string($db, $_POST['title']);
  $description = mysqli_real_escape_string($db, $_POST['description']);
  $role = mysqli_real_escape_string($db, $_POST['role']);
  $resource = mysqli_real_escape_string($db, $_POST['resource']);
  $jira_ticket = mysqli_real_escape_string($db, $_POST['jira_ticket']);


  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($title)) { array_push($errors, "Title is required"); }
  if (empty($description)) { array_push($errors, "Description is required"); }
  if (empty($resource)) { array_push($errors, "Resource is required"); }
  if (empty($jira_ticket)) { array_push($jira_ticket, "Jira Ticket no required"); }
  
  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	
  	$query = "INSERT INTO `projects` (`project_id`, `title`,`$jira_ticket`, `description`, `role`, `resource`, `added_on`) 
              VALUES 
              (NULL, '$title', '$jira_ticket', '$description', '$role', '$resource', current_timestamp())";
  	mysqli_query($db, $query);
  	$_SESSION['success'] = "Project Assigned Successfully";
  	header('location: index.php');
  }
}

?>