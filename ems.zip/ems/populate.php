<?php



#echo "Inside PHP";
$db = mysqli_connect('localhost', 'root', '', 'ems');
$role = $_POST['role'];
$sql = "SELECT fullname, username, role FROM users WHERE role = '$role'";
echo $sql;

   $result = mysqli_query($db, $sql);

print_r($result);
   $json = [];
   if(mysqli_num_rows($result) > 0){ 
        echo '<option value="">Select Resource</option>'; 
        while($row = mysqli_fetch_assoc($result)){  
            echo '<option value="'.$row['username'].'">'.$row['fullname'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">Resource not available</option>'; 
    } 

   // while($row = mysqli_fetch_assoc($result)){
   //      $json[$row['fullname']] = $row['username'];
   // }
   // echo json_encode($json);

?>