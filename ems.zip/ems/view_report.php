<?php 
  session_start(); 

  if (!isset($_SESSION['email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }
  $db = mysqli_connect('localhost', 'root', '', 'ems');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Project Hours Report</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header" style="width: 90%;">
  	<h2>Effors Management System- Reports</h2>
  </div>
  <div class="content" style="width: 90%;">
    	<!-- notification message -->
    	<?php if (isset($_SESSION['success'])) : ?>
        <div class="error success" >
        	<h3>
            <?php 
            	echo $_SESSION['success']; 
            	unset($_SESSION['success']);
            ?>
        	</h3>
        </div>
    	<?php endif; ?>

      <!-- logged in user information -->
      <?php  if (isset($_SESSION['email']))
      { ?>
        <p class="welcome">Welcome <strong><?php echo $_SESSION['fullname']; ?></strong>
        <a href="index.php?logout='1'" style="color: red; float: right;">logout</a> </p>
        <br>
        <br>
        <a class="btn btn-primary" href="register.php" role="button" style="margin-left:0px; ;">Add User</a>
        <a class="btn btn-primary" href="add_project.php" role="button" style="margin-left:0px; ;">Assign Project</a>        
        <a class="btn btn-primary" href="view_report.php" role="button" style="float: right;">View Report</a>      	
        <br>
        <br>
        <form action="view_report.php" method="POST" style="width: 90%;">  
        <?php if($_SERVER['REQUEST_METHOD'] == "GET")   #####GET method starts
        { ?>
        <label>Select Date</label>
        <input type="date" name="date">
        <label>User</label>
            <select name="user">
              <option value="">Select Resource</option>
              <?php
                  $sql_user = "select `id`, `fullname` from `users`";
                  $result_qry = mysqli_query($db, $sql_user);
                  for($i = 0; $i < mysqli_num_rows($result_qry); $i++) ###For Loop Starts
                    {
                      $row = mysqli_fetch_assoc($result_qry);
              ?>
              <option value="<?php echo $row['id']; ?>"><?php echo $row['fullname']; ?></option>
              <?php }  ###For loop ends ?> 
            </select>
        <button type="submit" class="btn" name="submit" style="margin-left: 0px;">Search</button>               
        <br>
        <br>
        <table id="hrs_table"> 
                <thead style="background-color: #5F9EA0;">
                  <th>Title</th>     
                  <th>Description</th>
                  <th>Jira Ticket</th>      
                  <th>Resource</th> 
                  <th>Date</th>         
                  <th>Total Time</th>
                  <th>Status</th>
                </thead>
                <tbody>
                  <?php                  
                      // $sql = "SELECT a.*, a.total_hrs + (a.total_minutes div 60) as total_hrs, (a.total_minutes mod 60) as total_minutes, b.jira_ticket, b.description FROM projects_hours_log as a inner join projects as b on a.project_id=b.project_id order by date desc";
                      // $sql = "SELECT a.*, concat(a.total_hrs + (a.total_minutes div 60), 'hrs', (a.total_minutes mod 60), 'min'), b.jira_ticket, b.description FROM projects_hours_log as a inner join projects as b on a.project_id=b.project_id order by date desc";
                        $sql = "SELECT a.*, c.fullname, concat((a.total_hrs + (a.total_minutes div 60)), ' hrs ', (a.total_minutes mod 60), ' min') as total_time, b.jira_ticket, b.description FROM projects_hours_log as a inner join projects as b on a.project_id=b.project_id inner join users c on a.user_id= c.id order by date desc";
                        #echo($sql);
                        $result = mysqli_query($db, $sql);
                        #print_r($result);
                        for($i = 0; $i < mysqli_num_rows($result); $i++)
                        {
                          $row = mysqli_fetch_assoc($result);
                            ?>
                              <tr>                
                                <td><?php echo $row['title']; ?></td>
                                <td style="width: 400px;"><?php echo $row['description']; ?></td>
                                <td><?php echo $row['jira_ticket']; ?></td>
                                <td><?php echo $row['fullname']; ?></td>
                                <td><?php echo $row['date']; ?></td>
                                <td><?php echo $row['total_time']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                              </tr>
                      <?php } ?>
        
            <?php
            } ####Get Method Ends
            else  ####Post menthod
            {?>
                <label>Select Date</label>
                <input type="date" name="date" style="height: 25px;">
                <label>User</label>
                <select name="user">
                  <option>Select Resource</option>
                <?php
                    $sql_user = "select `id`, `fullname` from `users`";
                    $result_qry = mysqli_query($db, $sql_user);
                    for($i = 0; $i < mysqli_num_rows($result_qry); $i++)
                      {
                        $row = mysqli_fetch_assoc($result_qry);
                ?>
                <option value="<?php echo $row['id']; ?>"><?php echo $row['fullname']; ?></option>
                <?php }?>
                </select>              
                <input type="submit" name="submit" value="Search" class="btn btn-primary" style="margin-left: 0px;"> 
                <br>  
                <br>   
                <table id="hrs_table"> 
                    <thead style="background-color: #5F9EA0;">
                      <th>Title</th>
                      <th>Jira Ticket</th>
                      <th>Description</th>           
                      <th>Resource</th> 
                      <th>Date</th>         
                      <th>Total Hrs Spent</th>           
                      <th>Status</th>
                </thead>
                <tbody>
                  <?php 
                  $report_date = $_POST['date'];
                  $user_id = $_POST['user'];
                  // $get_id = "select `id` from users where `fullname`='$user'";
                  // echo $get_id;
                  // $result_get_id = mysqli_query($db, $get_id);
                  // $rrr = mysqli_fetch_assoc($result_get_id);
                  // print_r($rrr);
                  // $user_id = $rrr['id'];
                  //echo $report_date."<br>";
                  //echo $user_id;
                  #echo "<br>".$user;
                  ####COnditions Starts for Filter Values
                  if(!empty($report_date)  && empty($user_id)){
                    // $sql = "SELECT *, concat((total_hrs)+(total_minutes div 60),' Hrs ',(total_minutes)%60,' Mins') as total_time_in_hrs FROM `projects_hours_log` WHERE  `date`= '$report_date'";
                    $sql = "SELECT a.*, c.fullname, concat((a.total_hrs + (a.total_minutes div 60)), ' hrs ', (a.total_minutes mod 60), ' min') as total_time, b.jira_ticket, b.description FROM projects_hours_log as a inner join projects as b on a.project_id=b.project_id inner join users c on a.user_id= c.id WHERE  `date`= '$report_date'";
                    //echo "<br>"."By Date"."<br>";
                    //echo $sql;
                  }
                  elseif(empty($report_date)  && !empty($user_id)){
                    // $sql = "SELECT *, concat((sum(total_hrs)+sum(total_minutes) div 60),' Hrs ',sum(total_minutes)%60,' Mins') as total_time_in_hrs FROM `projects_hours_log` where user_id='$user_id';";
                    // $sql = "SELECT *, concat((total_hrs+(total_minutes div 60)),' Hrs ',total_minutes %60,' Mins') as total_time_in_hrs FROM `projects_hours_log` where user_id='$user_id'";
                    $sql = "SELECT a.*, c.fullname, concat((a.total_hrs + (a.total_minutes div 60)), ' hrs ', (a.total_minutes mod 60), ' min') as total_time, b.jira_ticket, b.description FROM projects_hours_log as a inner join projects as b on a.project_id=b.project_id inner join users c on a.user_id= c.id where a.user_id='4'";
                    //echo "<br>"."By User"."<br>";                    
                    //echo $sql;
                  }
                  elseif(!empty($report_date)  && !empty($user_id))
                  {
                    $sql = "SELECT *, concat((sum(total_hrs)+sum(total_minutes) div 60),' Hrs ',sum(total_minutes)%60,' Mins') as total_time_in_hrs FROM `projects_hours_log` WHERE date ='$report_date' and `user_id` = '$user_id' ";
                    //echo "<br>"."By Both"."<br>";                    
                    //echo $sql;
                  }
                  else{
                     echo "Please select atleast one value to filter";
                  }
                  ##endif;
                  ####Conditions End for filter Values
                    #echo($sql);
                    $result = mysqli_query($db, $sql);
                    #print_r($result);
                    if(mysqli_num_rows($result) > 0)
                    {
                        for($i = 0; $i < mysqli_num_rows($result); $i++)
                        {
                          $row = mysqli_fetch_assoc($result);
                          $user_id = $row['user_id'];
                          $name_qry = "select `fullname` from users where id = '$user_id'";
                          // echo $name_qry;
                          $res_name = mysqli_query($db, $name_qry);
                          $rr = mysqli_fetch_assoc($res_name);
                          // print_r($rr);
                          $fullname = $rr['fullname'];
                          // /echo "--Full Name--".$fullname;
                            ?>
                              <tr>                
                                <td><?php echo $row['title']; ?></td>
                                <td><?php echo $row['jira_ticket']; ?></td>
                                <td><?php echo $row['description']; ?></td>
                                <td><?php echo $fullname; ?></td>
                                <td><?php echo (is_null($report_date)) ? $report_date : $row['date']; ?></td>
                                <td><?php echo $row['total_time']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                              </tr>
                    <?php
                        }
                    }
                    else
                    {
                      echo "No Data Available";
                    }                             
                    ##endif;
                }##endif;
            }##endif; ####Session Condition ends ?>    
          </tbody>          
        </table>
        </form>
  </div>    
</body>
</html>