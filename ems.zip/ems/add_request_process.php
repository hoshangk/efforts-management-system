<?php
include_once('functions.inc.php');
session_start();
 error_reporting(E_ERROR | E_WARNING | E_PARSE);
// initializing variables
$request_title = "";
$request_description  = "";
$request_category = "";
$channel = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'ems');

// REGISTER USER
if (isset($_POST['assign_request'])) {
  echo "Inside Process";
  // receive all input values from the form
  $email = $_SESSION['email'];
  $request_title = mysqli_real_escape_string($db, $_POST['title']);
  $request_description = mysqli_real_escape_string($db, $_POST['description']);
  $request_category = mysqli_real_escape_string($db, $_POST['category']);
  $channel = mysqli_real_escape_string($db, $_POST['channel']);
  $exp_del_date = mysqli_real_escape_string($db, $_POST['exp_del_date']);
  $requester_id = get_user_id($email, $db);

    echo $request_title."<br>";
    echo $request_description."<br>";
    echo $request_category."<br>";
    echo $channel."<br>";
    echo $exp_del_date."<br>";
    echo $requester_id."<br>";
    
  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($request_title)) { array_push($errors, "Title is required"); }
  if (empty($request_description)) { array_push($errors, "Description is required"); }
  //if (empty($exp_del_date)) { array_push($errors, "Resource is required"); }
  if (empty($channel)) { array_push($errors, "Channel no required"); }
  if (empty($request_category)) { array_push($errors, "Category is required"); }
  
  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {

      // print_r($errors);
        if(isset($_FILES['input_file'])){
          $target_dir = "uploads/";
          $target_file = $target_dir . basename($_FILES["input_file"]["name"]);
          print($target_file)."<br>";
          // exit;
          $errors= array();
          $file_name = $_FILES['input_file']['name'];
          $file_size = $_FILES['input_file']['size'];
          $file_tmp  = $_FILES['input_file']['tmp_name'];
          $file_type = $_FILES['input_file']['type'];
          $file_ext  = strtolower(end(explode('.',$_FILES['input_file']['name'])));
      
          echo $file_name."<br>";
          echo $file_size."<br>";
          echo $file_tmp."<br>";
          echo $file_type."<br>";
          echo $file_ext."<br>";
          $extensions= array("jpeg","jpg","png","pdf","obj","mp4","avi");
      
          if(in_array($file_ext,$extensions)=== false){
            $errors[]="Extension not allowed, please choose a JPEG or PNG file.";
          }
      
          if($file_size > 2097152){
            $errors[]='File size must be excately 2 MB';
          }
      
          if(empty($errors)==true){
            move_uploaded_file($file_tmp,"uploads/".$file_name);
            // echo "Success";
          }else{
            print_r($errors);
          }
          }
  	
  	$sql = "INSERT INTO `graphics_requests` (`requester_id`,`request_title`, `request_category`, `request_description`, `channel`, `exp_del_date`, `attachment_path`, `created_on`) VALUES ('$requester_id','$request_title', '$request_category', '$request_description', '$channel', '$exp_del_date','$target_file', CURRENT_TIMESTAMP)";
    echo $sql;
  	$ins_request = mysqli_query($db, $sql);
    if(mysqli_affected_rows($db)>=1){
        $_SESSION['success'] = "Request Submitted Successfully";
    }
    else{
        $_SESSION['success'] = "Request Not Submitted";
    }
  	header('location: index.php');
  }
}

?>